/**
 * CustomCBMForm — Left panel for custom CBM entry.
 *
 * Supports two pack modes:
 *   'single'   — a direct "Units per Shipper" input (original behaviour)
 *   'multiple' — two-tier entry: Units per Inner Carton × Inner Cartons per Master
 *                The effective packSize (innerPackQty × masterPackQty) is written
 *                to the shared form state via flushSync before the hook's
 *                handleAddToShipment runs, so the hook needs zero changes.
 */
import { useState } from 'react';
import { flushSync } from 'react-dom';
import FormInput from '../ui/FormInput';
import { PlusIcon, WarningIcon } from '../icons/Icons';

/* ─── small helpers ────────────────────────────────────────────────────────── */

const PACK_MODES = [
  { id: 'single',   label: 'Single Tier' },
  { id: 'multiple', label: 'Multi-Tier'  },
];

/* Pill-toggle shared style tokens */
const pillBase =
  'flex-1 py-2 px-3 text-[11px] font-bold uppercase tracking-wide rounded-full transition-all duration-200 focus:outline-none';
const pillActive =
  'bg-indigo-600 dark:bg-indigo-500 text-white shadow-md';
const pillInactive =
  'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200';

/* ─── component ─────────────────────────────────────────────────────────────── */

const CustomCBMForm = ({
  form,
  updateForm,
  unitSwitchWarning,
  previewCBM,
  canAdd,
  handleAddToShipment,
  handleAddToDirectory,
}) => {
  /* ── Local pack-mode state ── */
  const [packMode, setPackMode]       = useState('single');  // 'single' | 'multiple'
  const [innerPackQty, setInnerPackQty] = useState('');
  const [masterPackQty, setMasterPackQty] = useState('');

  const panelCls = 'glass rounded-2xl shadow-card dark:shadow-card-dark';

  /* ── Derived: effective total for multi-tier helper text ── */
  const innerNum  = Number(innerPackQty)  || 0;
  const masterNum = Number(masterPackQty) || 0;
  const multiTotal = innerNum * masterNum;

  /* ── Reset multi fields when switching back to single ── */
  const handlePackModeChange = (mode) => {
    setPackMode(mode);
    if (mode === 'single') {
      setInnerPackQty('');
      setMasterPackQty('');
    }
  };

  /**
   * Local add wrapper.
   * For 'multiple' mode we must patch `form.packSize` (and optionally
   * `form.packDetails`) in the hook's state *before* the hook's
   * handleAddToShipment closure reads it.
   * flushSync forces the React state flush synchronously so the next
   * read (inside handleAddToShipment) sees the updated value.
   */
  const handleAdd = () => {
    if (packMode === 'multiple' && multiTotal > 0) {
      flushSync(() => {
        updateForm('packSize',    multiTotal);
        updateForm('packDetails', {
          innerPackQty:  innerNum,
          masterPackQty: masterNum,
        });
      });
    }
    handleAddToShipment();

    /* Reset multi-tier fields after successful add */
    if (packMode === 'multiple') {
      setInnerPackQty('');
      setMasterPackQty('');
    }
  };

  /**
   * Local wrapper for adding to the product directory.
   * Same flushSync pattern as handleAdd to ensure packSize is up-to-date
   * before the hook reads the form state.
   */
  const handleAddToDir = () => {
    if (packMode === 'multiple' && multiTotal > 0) {
      flushSync(() => {
        updateForm('packSize',    multiTotal);
        updateForm('packDetails', {
          innerPackQty:  innerNum,
          masterPackQty: masterNum,
        });
      });
    }
    handleAddToDirectory();

    /* Reset multi-tier fields after successful add */
    if (packMode === 'multiple') {
      setInnerPackQty('');
      setMasterPackQty('');
    }
  };

  return (
    <section className="lg:col-span-3 fade-in" style={{ animationDelay: '0.05s' }}>
      <div className={`${panelCls} p-4 sm:p-5`}>

        {/* ── Section header ── */}
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-900/60 flex items-center justify-center flex-shrink-0">
            <svg
              className="w-4 h-4 text-indigo-600 dark:text-indigo-400 no-theme-transition"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
              strokeWidth={2}
            >
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
            </svg>
          </div>
          <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 truncate">
            Custom CBM Entry
          </h2>
        </div>

        {/* ── Item Name ── */}
        <div className="mb-4">
          <FormInput
            id="item-name"
            label="Item Name"
            type="text"
            value={form.name}
            onChange={(v) => updateForm('name', v)}
          />
        </div>

        {/* ── Unit selector ── */}
        <div className="mb-4 space-y-1.5">
          <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            Unit
          </label>
          <div className="grid grid-cols-5 gap-1.5">
            {['mm', 'cm', 'inches', 'feet', 'meters'].map((u) => (
              <button
                key={u}
                id={`unit-${u}`}
                onClick={() => updateForm('unit', u)}
                className={`py-2 px-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wide max-w-full truncate
                  ${form.unit === u
                    ? 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-600 shadow-glow'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-600 hover:border-slate-300 dark:hover:border-slate-500'
                  }`}
              >
                {u}
              </button>
            ))}
          </div>
        </div>

        {/* ── Unit switch warning ── */}
        {unitSwitchWarning && (
          <div className="mb-3 p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 flex items-start gap-2 fade-in">
            <span className="text-amber-500 flex-shrink-0 mt-0.5">
              <WarningIcon />
            </span>
            <p className="text-[11px] text-amber-700 dark:text-amber-400 font-medium">
              Values not converted — existing dimensions are now treated as{' '}
              <strong>{form.unit}</strong>.
            </p>
          </div>
        )}

        {/* ── Dimensions ── */}
        <div className="grid grid-cols-1 min-[400px]:grid-cols-3 gap-2 mb-4">
          <FormInput
            id="dim-length"
            label="L"
            value={form.length}
            onChange={(v) => updateForm('length', v)}
            suffix={form.unit.slice(0, 2)}
          />
          <FormInput
            id="dim-width"
            label="W"
            value={form.width}
            onChange={(v) => updateForm('width', v)}
            suffix={form.unit.slice(0, 2)}
          />
          <FormInput
            id="dim-height"
            label="H"
            value={form.height}
            onChange={(v) => updateForm('height', v)}
            suffix={form.unit.slice(0, 2)}
          />
        </div>

        {/* ══════════════ PACK SIZE SECTION ══════════════ */}
        <div className="mb-4 space-y-2">

          {/* ── Pack mode pill-toggle ── */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              Pack Configuration
            </label>
            <div className="flex gap-1 p-1 rounded-full bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
              {PACK_MODES.map(({ id, label }) => (
                <button
                  key={id}
                  id={`pack-mode-${id}`}
                  onClick={() => handlePackModeChange(id)}
                  className={`${pillBase} ${packMode === id ? pillActive : pillInactive}`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* ── Single-tier: standard Units per Shipper ── */}
          {packMode === 'single' && (
            <div className="fade-in">
              <FormInput
                id="pack-size"
                label="Quantity Per Shipper"
                value={form.packSize}
                onChange={(v) => updateForm('packSize', v)}
                min="1"
                step="1"
                suffix="pcs"
              />
            </div>
          )}

          {/* ── Multi-tier: inner × master grid ── */}
          {packMode === 'multiple' && (
            <div className="fade-in space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <FormInput
                  id="inner-pack-qty"
                  label="Units / Inner Carton"
                  value={innerPackQty}
                  onChange={(v) => setInnerPackQty(v)}
                  min="1"
                  step="1"
                  suffix="pcs"
                />
                <FormInput
                  id="master-pack-qty"
                  label="Inners / Master Carton"
                  value={masterPackQty}
                  onChange={(v) => setMasterPackQty(v)}
                  min="1"
                  step="1"
                  suffix="ctn"
                />
              </div>

              {/* Dynamic helper text */}
              <div
                className={`flex items-center justify-between px-3 py-2 rounded-lg border transition-colors duration-200
                  ${multiTotal > 0
                    ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-700'
                    : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700'
                  }`}
              >
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  {innerNum > 0 && masterNum > 0
                    ? `${innerNum} × ${masterNum}`
                    : 'Total'}
                </span>
                <span
                  className={`text-sm font-bold font-mono tabular-nums
                    ${multiTotal > 0
                      ? 'text-indigo-600 dark:text-indigo-400'
                      : 'text-slate-400 dark:text-slate-600'
                    }`}
                >
                  {multiTotal > 0
                    ? `= ${multiTotal.toLocaleString()} units / master`
                    : '—'}
                </span>
              </div>
            </div>
          )}

          {/* ── Total Pcs (always visible) ── */}
          <FormInput
            id="total-pcs"
            label="Total Pcs"
            value={form.totalPcs || ''}
            onChange={(v) => updateForm('totalPcs', v)}
            min="0"
            step="1"
            suffix="pcs"
          />

          {/* Shipper count derivation row */}
          {(() => {
            const effectivePack =
              packMode === 'multiple' ? multiTotal : Number(form.packSize);
            return form.totalPcs > 0 && effectivePack > 0 ? (
              <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-700 fade-in">
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">
                  {form.totalPcs} ÷ {effectivePack}
                </span>
                <span className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  = {Math.ceil(form.totalPcs / effectivePack)} shippers
                </span>
              </div>
            ) : null;
          })()}
        </div>

        {/* ── Weights ── */}
        <div className="grid grid-cols-2 gap-2 mb-2">
          <FormInput
            id="net-weight"
            label="Net Wt/Shipper"
            value={form.netWeight}
            onChange={(v) => updateForm('netWeight', v)}
            suffix="kg"
          />
          <FormInput
            id="gross-weight"
            label="Gross Wt/Shipper"
            value={form.grossWeight}
            onChange={(v) => updateForm('grossWeight', v)}
            suffix="kg"
          />
        </div>

        {/* Weight totals summary */}
        {(Number(form.netWeight) > 0 || Number(form.grossWeight) > 0) && (
          <>
            <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 mb-2 fade-in">
              {(() => {
                const effectivePack =
                  packMode === 'multiple' ? multiTotal : Number(form.packSize);
                const shippers =
                  form.totalPcs > 0 && effectivePack > 0
                    ? Math.ceil(Number(form.totalPcs) / effectivePack)
                    : 1;
                return (
                  <>
                    <div className="flex flex-col">
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                        Total Net Wt
                      </span>
                      <span className="text-sm font-bold font-mono text-slate-700 dark:text-slate-300">
                        {((Number(form.netWeight) || 0) * shippers).toFixed(2)} kg
                      </span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider">
                        Total Gross Wt
                      </span>
                      <span className="text-sm font-bold font-mono text-slate-700 dark:text-slate-300">
                        {((Number(form.grossWeight) || 0) * shippers).toFixed(2)} kg
                      </span>
                    </div>
                  </>
                );
              })()}
            </div>

            {/* Per-pcs weight breakdown */}
            {(() => {
              const effectivePack =
                packMode === 'multiple' ? multiTotal : Number(form.packSize);
              const perPcsNet   = effectivePack > 0 ? (Number(form.netWeight)   || 0) / effectivePack : 0;
              const perPcsGross = effectivePack > 0 ? (Number(form.grossWeight) || 0) / effectivePack : 0;
              const hasData = effectivePack > 0 && (perPcsNet > 0 || perPcsGross > 0);
              return hasData ? (
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 mb-5 fade-in">
                  <div className="flex flex-col">
                    <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold uppercase tracking-wider">
                      Net Wt / Pcs
                    </span>
                    <span className="text-sm font-bold font-mono text-amber-700 dark:text-amber-300">
                      {perPcsNet.toFixed(2)} kg
                    </span>
                  </div>
                  <div className="w-px h-8 bg-amber-200 dark:bg-amber-700/50" />
                  <div className="flex flex-col items-end">
                    <span className="text-[10px] text-amber-600 dark:text-amber-400 font-semibold uppercase tracking-wider">
                      Gross Wt / Pcs
                    </span>
                    <span className="text-sm font-bold font-mono text-amber-700 dark:text-amber-300">
                      {perPcsGross.toFixed(2)} kg
                    </span>
                  </div>
                </div>
              ) : <div className="mb-5" />;
            })()}
          </>
        )}

        {/* ── Volume preview ── */}
        {previewCBM > 0 && (
          <div className="mb-4 p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-800 fade-in">
            <div className="flex justify-between items-center gap-2">
              <span className="text-xs text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold flex items-center gap-1.5">
                Volume Preview
                {form.presetCBM > 0 && !form.length && !form.width && !form.height && (
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-violet-100 dark:bg-violet-900/50 text-violet-600 dark:text-violet-400 border border-violet-200 dark:border-violet-700 uppercase tracking-wide">
                    pre-calc
                  </span>
                )}
              </span>
              <span className="text-base font-bold font-mono text-indigo-600 dark:text-indigo-400 tabular-nums">
                {previewCBM.toFixed(2)} m³
              </span>
            </div>
          </div>
        )}

        {/* ── Add buttons ── */}
        <div className="flex flex-col gap-2">
          <button
            id="add-to-shipment-btn"
            onClick={handleAdd}
            disabled={!canAdd}
            className={`w-full max-w-full py-3 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2
              ${canAdd
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white hover:from-indigo-500 hover:to-violet-500 hover:shadow-glow active:scale-[0.98]'
                : 'bg-slate-100 dark:bg-slate-700/50 text-slate-400 dark:text-slate-500 cursor-not-allowed border border-slate-200 dark:border-slate-600'
              }`}
          >
            <PlusIcon /> Add to Shipment
          </button>

          <button
            id="add-to-directory-btn"
            onClick={handleAddToDir}
            disabled={!canAdd}
            className={`w-full max-w-full py-2.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2
              ${canAdd
                ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-700 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 active:scale-[0.98] transition-colors'
                : 'bg-transparent text-slate-400 dark:text-slate-500 cursor-not-allowed border border-slate-200 dark:border-slate-600'
              }`}
          >
            <PlusIcon /> Add to Product Directory
          </button>
        </div>
      </div>
    </section>
  );
};

export default CustomCBMForm;
